# Content-Management-Tool
As per the Bharat Intern Content Management Tool is given as a Task, This Tool is useful for the users as they can add images and videos and refer them anytime.
